import customtkinter
import CRISPRcolab as glib
from Bio.Seq import Seq
from Bio import SeqIO, Entrez
import numpy as np

#from selenium import webdriver
#from selenium.webdriver.chrome.service import Service
#from selenium.webdriver.common.by import By
#from selenium.webdriver.common.keys import Keys
#from selenium.webdriver.common.action_chains import ActionChains
#from selenium.webdriver.support.ui import WebDriverWait
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.webdriver.chrome.options import Options
#from webdriver_manager.chrome import ChromeDriverManager
import time



class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()

        self.title("gRNA Library")
        self.geometry('1080x600')
        self.grid_columnconfigure(0, weight=1, uniform='a')

        self.local_or_online()
        #self.reinstate_gRNA_elements()

    def reinstate_gRNA_elements(self):
        self.clear_frames()
        self.title_1 = customtkinter.CTkLabel(self, text='Guide RNA Library', font=('Arial', 120))
        self.title_1.place(relx=0.5, rely=0, anchor='n', relwidth=1, relheight=0.1)

        self.input_frame = customtkinter.CTkFrame(self)
        self.input_frame.place(relx=0.5, rely=0.1, anchor='n', relwidth=1, relheight=0.3)
        #self.input_frame.grid(row=1, column=0, padx=0, pady=(10, 0), sticky="ew")
        #self.input_frame.grid_rowconfigure(0, weight=1)
        #self.input_frame.grid_columnconfigure(0, weight=1)


        self.down_from_db = customtkinter.IntVar()
        self.load_from_file_var = customtkinter.IntVar()
        self.ncbi_button = customtkinter.CTkCheckBox(self.input_frame, text="Download from database", variable=self.down_from_db, font=('Helvetica', 40, 'bold'))
        self.ncbi_button.place(relx=0, rely=0, anchor='nw', relwidth=0.4, relheight=0.15)
        self.load_from_file_button = customtkinter.CTkCheckBox(self.input_frame, text='Load from a file', variable=self.load_from_file_var, font=('Helvetica', 40, 'bold'))
        self.load_from_file_button.place(relx=0.4, rely=0, anchor='nw', relwidth=0.4, relheight=0.15)
        self.down_from_db.trace('w', self.download_from_db)
        self.load_from_file_var.trace('w', self.load_from_file)


        self.entry1 = customtkinter.CTkTextbox(self.input_frame, font=('Helvetica', 45, 'bold'))
        self.entry1.place(relx=0.5, rely=0.15, anchor='n', relwidth=1, relheight=0.5)
        #self.entry1.grid(row=0, column=0, pady=12, padx=10, sticky= "ew", columnspan=3)
        self.entry1.insert("0.0", "Input gene sequence from 5' to 3' here")

        self.cas_var = customtkinter.IntVar()
        self.cas_box = customtkinter.CTkCheckBox(self.input_frame, text='Not Sp Cas9?', variable=self.cas_var, font=('Helvetica', 50, 'bold'))
        self.cas_box.place(relx=0.5, rely=0.65, anchor='n', relwidth=1, relheight=0.1)
        #self.cas_box.grid(row=1, column=0, pady=12, padx=10, sticky='nsew')
        self.cas_var.trace('w', self.custom_cas_box)
    
        self.button = customtkinter.CTkButton(self.input_frame, text='Find gRNA candidates', command=self.receiver, font=('Helvetica', 50, 'bold'))
        self.button.place(relx=0.5, rely=1, anchor='s', relwidth=1, relheight=0.2)
        #self.button.grid(row=3, column=0, pady=12, padx=10, sticky='ew', columnspan=2)
        
        self.output_frame = customtkinter.CTkFrame(self)
        self.output_frame.place(relx=0.5, rely=0.4, anchor='n', relwidth=1, relheight=0.6)
        #self.output_frame.grid(row=2, column=0, padx=0, pady=(10, 0), sticky="ew")
        #self.output_frame.grid_columnconfigure((0, 1), weight=1)
        
        self.out_explanation = customtkinter.CTkLabel(self.output_frame, text='Output:{gRNA sequence, position, PAM}', font=('Helvetica', 50, 'bold'))
        self.out_explanation.place(relx=0.5, rely=0, anchor='n', relwidth=1, relheight=0.1)
        #self.out_explanation.grid(row=0, column=0, pady=12, padx=10, sticky='ew')
        
        self.label_positive = customtkinter.CTkLabel(self.output_frame, text='On the Positive strand:', font=('Helvetica', 50, 'bold'))
        self.label_positive.place(relx=0.5, rely=0.1, anchor='n', relwidth=1, relheight=0.1)
        #self.label_positive.grid(row=1, column=0, pady=12, padx=10, sticky='nsew')
        self.output1 = customtkinter.CTkTextbox(self.output_frame)
        self.output1.place(relx=0.5, rely=0.2, anchor='n', relwidth=1, relheight=0.3)
        #self.output1.grid(row=2, column=0, pady=12, padx=10, sticky='ew', columnspan=3)
        self.output1.configure(font=('Helvetica', 30, 'bold'))  # Change the font size to 30 and make it bold

        self.label_negative = customtkinter.CTkLabel(self.output_frame, text='On the Negative strand:', font=('Helvetica', 50, 'bold'))
        self.label_negative.place(relx=0.5, rely=0.5, anchor='n', relwidth=1, relheight=0.1)
        #self.label_negative.grid(row=3, column=0, pady=12, padx=10, sticky='nsew')
        self.output2 = customtkinter.CTkTextbox(self.output_frame)
        self.output2.place(relx=0.5, rely=0.6, anchor='n', relwidth=1, relheight=0.3)
        #self.output2.grid(row=4, column=0, pady=12, padx=10, sticky='ew', columnspan=3)
        self.output2.configure(font=('Helvetica', 30, 'bold'))  # Change the font size to 30 and make it bold

        self.button2 = customtkinter.CTkButton(self.output_frame, text='Rank Candidates', command=self.reinstate_ranking_elements, font=('Helvetica', 50, 'bold')) 
        self.button2.place(relx=1, rely=1, anchor='se', relwidth=0.85, relheight=0.1)
        #self.button2.grid(row=5, column=0, pady=12, padx=10, sticky='ew', columnspan=2)

        self.home_button = customtkinter.CTkButton(self.output_frame, text='Home', command=self.local_or_online, font=('Helvetica', 50, 'bold'))
        self.home_button.place(relx=0, rely=1, anchor='sw', relwidth=0.15, relheight=0.1)
    
    def clear_frames(self):
        if hasattr(self, 'local_or_online_frame'):
            for widget in self.local_or_online_frame.winfo_children():
                widget.destroy()
        if hasattr(self, 'input_frame'):
            #self.input_frame.destroy()
            for widget in self.input_frame.winfo_children():
                widget.destroy()
        if hasattr(self, 'output_frame'):
            #self.output_frame.destroy()
            for widget in self.output_frame.winfo_children():
                widget.destroy()

    def receiver(self):
        self.output1.delete("0.0", "end")
        self.output2.delete("0.0", "end")
        #print(self.custom_cas.get().replace('[', '').replace(']', '').split(','))
        #print(self.custom_cas.get().replace('[', '').replace(']', '').split(','))
        #print(self.custom_cas.get().replace('[', '').replace(']', '').split(','))
        #print(self.custom_cas.get().replace('[', '').replace(']', '').split(','))
        if hasattr(self, 'custom_cas'):
            if self.down_from_db.get() == 1 and self.load_from_file_var.get() == 0:
                print(self.entry1.get('0.0', 'end').split(';'))
                user_email, gene_ids, dbase, format_desired, gimmick = self.entry1.get('0.0', 'end').split(';')
                gene_ids = list(gene_ids.replace('(', '').replace(')', ''))
                Entrez.email = user_email
                handle = Entrez.efetch(db=dbase, id=gene_ids, rettype=format_desired, retmode="text")
                gene_sequence = SeqIO.parse(handle, format_desired)
                #globals()["gRNA_list_plus"]= []
                #globals()["gRNA_list_minus"] = []
                records = [x for x in gene_sequence]

                for n in range(len(records)):
                    aux_list_plus = []
                    aux_list_minus = []
                    print(self.custom_cas.get().replace('[', '').replace(']', '').split(','))
                    aux_list_plus, aux_list_minus = glib.main(records[n].seq.upper(), PAM=[pam for pam in self.custom_cas.get().replace('[', '').replace(']', '').split(',')])
                    globals()["gRNA_list_plus"].append(aux_list_plus)
                    globals()["gRNA_list_minus"].append(aux_list_minus)

            elif self.down_from_db.get() == 0 and self.load_from_file_var.get() == 1:
                # I want to be able to parse a sequence from a file specified by the user
                with open(self.entry1.get('0.0', 'end').replace('\n',''), 'r') as handle:
                    gene_sequence = SeqIO.read(handle, "fasta")
                
                print(self.custom_cas.get().replace('[', '').replace(']', '').split(','))
                aux_result = glib.main(gene_sequence.seq.upper(), PAM=[pam for pam in self.custom_cas.get().replace('[', '').replace(']', '').split(',')])
                print(aux_result)
                globals()["gRNA_list_plus"], globals()["gRNA_list_minus"] = aux_result[::2], aux_result[1::2]
            
            else:
                globals()["gRNA_list_plus"], globals()["gRNA_list_minus"] = glib.main(Seq(self.entry1.get('0.0', 'end')).upper(), PAM=[pam for pam in self.custom_cas.get().replace('[', '').replace(']', '').split(',')])
        
        else:
            if self.down_from_db.get() == 1 and self.load_from_file_var.get() == 0:
                print(self.entry1.get('0.0', 'end').split(';'))
                user_email, gene_ids, dbase, format_desired, gimmick = self.entry1.get('0.0', 'end').split(';')
                gene_ids = list(gene_ids.replace('(', '').replace(')', ''))
                Entrez.email = user_email
                handle = Entrez.efetch(db=dbase, id=gene_ids, rettype=format_desired, retmode="text")
                gene_sequence = SeqIO.parse(handle, format_desired)
                globals()["gRNA_list_plus"]= []
                globals()["gRNA_list_minus"] = []
                records = [x for x in gene_sequence]

                for n in range(len(records)):
                    aux_list_plus = []
                    aux_list_minus = []
                    aux_list_plus, aux_list_minus = glib.main(records[n].seq.upper())
                    globals()["gRNA_list_plus"].append(aux_list_plus)
                    globals()["gRNA_list_minus"].append(aux_list_minus)
            
            elif self.down_from_db.get() == 0 and self.load_from_file_var.get() == 1:
                with open(self.entry1.get('0.0', 'end').replace('\n',''), 'r') as handle:
                    gene_sequence = SeqIO.read(handle, "fasta")
                globals()["gRNA_list_plus"], globals()["gRNA_list_minus"] = glib.main(gene_sequence.seq.upper())
            
            else:
                globals()["gRNA_list_plus"], globals()["gRNA_list_minus"] = glib.main(Seq(self.entry1.get('0.0', 'end')).upper())
        
        self.output1.insert("0.0", gRNA_list_plus)
        self.output2.insert("0.0", gRNA_list_minus)

    def custom_cas_box(self, *args):
        if self.cas_var.get() == 1:
            self.custom_cas = customtkinter.CTkEntry(self.input_frame, font=('Helvetica', 30, 'bold'), placeholder_text='Enter the PAM sequence')
            self.custom_cas.place(relx=0, rely=0.65, anchor='nw', relwidth=0.5, relheight=0.15)
            self.custom_cut_site = customtkinter.CTkEntry(self.input_frame, font=('Helvetica', 30, 'bold'), placeholder_text='(Cut on positive; cut on negative)')
            self.custom_cut_site.place(relx=0.5, rely=0.65, anchor='nw', relwidth=0.5, relheight=0.15)
            #self.custom_cas.grid(row=2, column=0, pady=12, padx=10, sticky='nsew', columnspan=2)
            #self.custom_cas.insert("0.0", 'Enter the PAM sequence with N for any base. Ex: NGG')
            #self.custom_cas.grid_columnconfigure((0, 1), weight=1)
        else:
            if hasattr(self, 'custom_cas'):
                self.custom_cas.destroy()

    def download_from_db(self, *args):
        if self.down_from_db.get() == 1 and self.load_from_file_var.get() == 0:
            self.entry1.delete("0.0", "end")
            self.entry1.insert("0.0", """Enter the information in the following order: \n your_email; (gene_id1, gene_id2, ...); database; format""")
            #self.ncbi_button.configure(command=self.download_from_ncbi)
            #self.load_from_file_button.configure(command=self.load_from_file)
        else:
            self.entry1.delete("0.0", "end")
            self.entry1.insert("0.0", "Please, select only one option, or turn both off for manual input of sequence")

    def load_from_file(self, *args):
        if self.load_from_file_var.get() == 1 and self.down_from_db.get() == 0:
            self.entry1.delete("0.0", "end")
            self.entry1.insert("0.0", """Input path to gene file here. Can be obtained from the properties section of the file plus the name of the file itself. Example: C:/Users/username/Desktop/gene.fasta""")
            #self.load_from_file_button.configure(command=self.load_from_file)
            #self.ncbi_button.configure(command=self.download_from_ncbi)
        else:
            self.entry1.delete("0.0", "end")
            self.entry1.insert("0.0", "Please, select only one option, or turn both off for manual input of sequence")

    def reinstate_ranking_elements(self):
        globals()['ranking'] = []
        self.clear_frames()
        self.title_1 = customtkinter.CTkLabel(self, text='Guide RNA Library', font=('Arial', 120))
        self.title_1.place(relx=0.5, rely=0, anchor='n', relwidth=1, relheight=0.1)

        self.input_frame = customtkinter.CTkFrame(self)
        self.input_frame.place(relx=0.5, rely=0.1, anchor='n', relwidth=1, relheight=0.4)

        self.down_from_db = customtkinter.IntVar()
        self.load_from_file_var = customtkinter.IntVar()
        self.ncbi_button = customtkinter.CTkCheckBox(self.input_frame, text="Download from database", variable=self.down_from_db, font=('Helvetica', 40, 'bold'))
        self.ncbi_button.place(relx=0, rely=0, anchor='nw', relwidth=0.4, relheight=0.15)
        self.load_from_file_button = customtkinter.CTkCheckBox(self.input_frame, text='Load from a file', variable=self.load_from_file_var, font=('Helvetica', 40, 'bold'))
        self.load_from_file_button.place(relx=0.4, rely=0, anchor='nw', relwidth=0.4, relheight=0.15)
        self.down_from_db.trace('w', self.download_from_db)
        self.load_from_file_var.trace('w', self.load_from_file)

        self.entry1 = customtkinter.CTkTextbox(self.input_frame, font=('Helvetica', 45, 'bold'))
        self.entry1.place(relx=0.5, rely=0.15, anchor='n', relwidth=1, relheight=0.8)
        self.entry1.insert("0.0", "Input the genome sequence to be screened from 5' to 3' here or select one of the buttons above for more options of loading a genome")
    
        self.run_button = customtkinter.CTkButton(self.input_frame, text='Run', command=self.rank_candidates, font=('Helvetica', 50, 'bold'))
        self.run_button.place(relx=0.5, rely=0.9, anchor='n', relwidth=1, relheight=0.1)
        
        self.output_frame = customtkinter.CTkFrame(self)
        self.output_frame.place(relx=0.5, rely=0.5, anchor='n', relwidth=1, relheight=0.5)
        
        self.label_positive = customtkinter.CTkLabel(self.output_frame, text='gRNA sequences Ranking and Overall Score:', font=('Helvetica', 50, 'bold'))
        self.label_positive.place(relx=0.5, rely=0, anchor='n', relwidth=1, relheight=0.15)
        self.out_explanation = customtkinter.CTkLabel(self.output_frame, text='Output:{gRNA sequence, Nº off-targets, GC content, \n Secondary Structure, Poly-T, Overall score}', font=('Helvetica', 40, 'bold'))
        self.out_explanation.place(relx=0.5, rely=0.15, anchor="n", relwidth=1, relheight=0.2)
        self.output1 = customtkinter.CTkTextbox(self.output_frame)
        self.output1.place(relx=0.5, rely=0.35, anchor='n', relwidth=1, relheight=0.5)
        self.output1.configure(font=('Helvetica', 40, 'bold'))

        self.button_3 = customtkinter.CTkButton(self.output_frame, text='Find new gRNAs', command=self.reinstate_gRNA_elements, font=('Helvetica', 50, 'bold'))
        self.button_3.place(relx=0.5, rely=0.85, anchor='nw', relwidth=0.5, relheight=0.1)
        self.button_4 = customtkinter.CTkButton(self.output_frame, text='Save to csv', command=self.save_to_csv, font=('Helvetica', 50, 'bold'))
        self.button_4.place(relx=0, rely=0.85, anchor='nw', relwidth=0.5, relheight=0.1)
        self.button_5 = customtkinter.CTkButton(self.output_frame, text='Home', command=self.local_or_online, font=('Helvetica', 50, 'bold'))
    
    def rank_candidates(self):
        if self.down_from_db.get() == 1 and self.load_from_file_var.get() == 0:
            print(self.entry1.get('0.0', 'end').split(';'))
            user_email, gene_ids, dbase, format_desired, gimmick = self.entry1.get('0.0', 'end').split(';')
            gene_ids = list(gene_ids.replace('(', '').replace(')', ''))
            Entrez.email = user_email
            handle = Entrez.efetch(db=dbase, id=gene_ids, rettype=format_desired, retmode="text")
            genome_sequence = SeqIO.parse(handle, format_desired)
            records = [x for x in genome_sequence]

            for n in range(len(records)):
                aux_ranking = []
                aux_ranking = glib.gRNA_ranking((globals()["gRNA_list_plus"]+globals()["gRNA_list_minus"]), records[n].seq.upper(), True if self.cas_var.get() == 0 else False)
                globals()["ranking"].append(aux_ranking)

        elif self.down_from_db.get() == 0 and self.load_from_file_var.get() == 1:
            with open(self.entry1.get('0.0', 'end').replace('\n',''), 'r') as handle:
                genome_sequence = SeqIO.read(handle, "fasta")
            print("Hey, you are on the right one")
            #print("Understanding the shape",np.array(globals()["gRNA_list_plus"]).shape())
            print(globals()["gRNA_list_plus"])
            globals()["ranking"] = glib.gRNA_ranking((globals()["gRNA_list_plus"]+globals()["gRNA_list_minus"]), genome_sequence.seq.upper(), True if self.cas_var.get() == 0 else False)
        
        else:
            globals()['ranking'] = glib.gRNA_ranking((globals()["gRNA_list_plus"]+globals()["gRNA_list_minus"]), self.entry1.get('0.0', 'end').upper(), True if self.cas_var.get() == 0 else False)

        #globals()['ranking'] = glib.gRNA_ranking((globals()["gRNA_list_plus"]+globals()["gRNA_list_minus"]), self.entry1.get('0.0', 'end').upper(), True if self.cas_var.get() == 1 else False)
        self.output1.delete("0.0", "end")
        aux_rank_list = [(str_x[0] + ' , ' + str_x[1] + ' , ' + str_x[2] + ' , ' + str_x[3] +
                          ' , ' + str_x[4] + ' , ' + str_x[5]
                          ) for str_x in globals()['ranking']]
        self.output1.insert("0.0", '\n'.join(aux_rank_list))

    def local_or_online(self):
        #self.clear_frames()
        self.local_or_online_frame = customtkinter.CTkFrame(self)
        self.local_or_online_frame.place(relx=0.5, rely=0.5, anchor='center', relwidth=1, relheight=1)
        self.title_1 = customtkinter.CTkLabel(self.local_or_online_frame, text='Guide RNA Library', font=('Arial', 120))
        self.title_1.place(relx=0.5, rely=0.3, anchor='center', relwidth=1, relheight=0.2)

        self.choice_frame = customtkinter.CTkFrame(self.local_or_online_frame)
        self.choice_frame.place(relx=0.5, rely=0.5, anchor='n', relwidth=0.9, relheight=0.5)
        
        self.question = customtkinter.CTkLabel(self.choice_frame, text='Do you want to run \n on the cloud or locally?', font=('Helvetica', 50, 'bold'))
        self.question.place(relx=0.5, rely=0.25, anchor='n')

        self.checkbutton_1 = customtkinter.CTkButton(self.choice_frame, text='Locally', command=self.reinstate_gRNA_elements, font=('Helvetica', 50, 'bold'))
        self.checkbutton_1.place(relx=0.5, rely=0.55, anchor='center')

        self.checkbutton_2 = customtkinter.CTkButton(self.choice_frame, text='On the cloud', command=self.reinstate_selenium_elements, font=('Helvetica', 50, 'bold'))
        self.checkbutton_2.place(relx=0.5, rely=0.75, anchor='center')

    def reinstate_selenium_elements(self):
        self.clear_frames()
        self.title_1 = customtkinter.CTkLabel(self, text='Guide RNA Library', font=('Arial', 120))
        self.title_1.place(relx=0.5, rely=0, anchor='n', relwidth=1, relheight=0.2)
        #self.title_1.grid(row=0, column=0, pady=12, padx=10, sticky='ew')

        self.input_frame = customtkinter.CTkFrame(self)
        self.input_frame.place(relx=0.5, rely=0.2, anchor='n', relwidth=1, relheight=0.3)
        #self.input_frame.grid(row=1, column=0, padx=0, pady=(10, 0), sticky="ew")
        #self.input_frame.grid_columnconfigure(0, weight=1, uniform='a')

        self.entry1 = customtkinter.CTkTextbox(self.input_frame, font=('Helvetica', 50, 'bold'))
        self.entry1.place(relx=0.5, rely=0.1, anchor='n', relwidth=1, relheight=0.5)
        #self.entry1.grid(row=0, column=0, pady=12, padx=10, sticky= "ew", columnspan=3)
        self.entry1.insert("0.0", "Input the genome sequence to be screened from 5' to 3' here")
    
        self.button = customtkinter.CTkButton(self.input_frame, text='Run', command=selenium_colab, font=('Helvetica', 50, 'bold'))
        self.button.place(relx=0.5, rely=1, anchor='s', relwidth=1, relheight=0.2)
        #self.button.grid(row=3, column=0, pady=12, padx=10, sticky='ew', columnspan=2)
        
        self.output_frame = customtkinter.CTkFrame(self)
        self.output_frame.place(relx=0.5, rely=0.5, anchor='n', relwidth=1, relheight=0.5)
        #self.output_frame.grid(row=2, column=0, padx=0, pady=(10, 0), sticky="ew")
        #self.output_frame.grid_columnconfigure(0, weight=1, uniform='a')
        
        self.label_positive = customtkinter.CTkLabel(self.output_frame, text='gRNA sequences Ranking and Overall Score:', font=('Helvetica', 50, 'bold'))
        self.label_positive.place(relx=0.5, rely=0, anchor='n', relwidth=1, relheight=0.1)
        #self.label_positive.grid(row=0, column=0, pady=12, padx=10, sticky='nsew')
        self.out_explanation = customtkinter.CTkLabel(self.output_frame, text='Output:\n{gRNA sequence, Number of miss-matches, Overall score}', font=('Helvetica', 50, 'bold'))
        self.out_explanation.place(relx=0.5, rely=0.1, anchor='n', relwidth=1, relheight=0.1)
        #self.out_explanation.grid(row=1, column=0, pady=12, padx=10, sticky='ew')
        self.output1 = customtkinter.CTkTextbox(self.output_frame)
        self.output1.place(relx=0.5, rely=0.2, anchor='n', relwidth=1, relheight=0.3)
        #self.output1.grid(row=2, column=0, pady=12, padx=10, sticky='ew', columnspan=3)

        self.home_button = customtkinter.CTkButton(self.output_frame, text='Home', command=self.local_or_online, font=('Helvetica', 50, 'bold'))
        self.home_button.place(relx=0, rely=1, anchor='sw', relwidth=0.15, relheight=0.15)

    def save_to_csv(self):
        glib.save_to_csv("/home/fertroll10/Documents/gRNA_lib/", globals()['ranking'])

def selenium_colab():
    chrome_options = Options()
    chrome_options.add_experimental_option('detach', True)

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

    driver.get('https://colab.research.google.com/')
    driver.maximize_window()

    action = ActionChains(driver)

    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, '//a[contains(@aria-label, "Sign in")]'))
    )
    xpath_sign_in = '//a[contains(@aria-label, "Sign in")]'
    results = driver.find_element(By.XPATH, xpath_sign_in)
    results.click()

    #The code bellow will be responsible to make the driver wait indiscriminately
    time.sleep(50)
    """ So, everything seems to be working up until the point where
    I touch the sign in buttom. This is super cool.
    The next steps are likely to be where the user will be asked to manually sign in
    to their google account. I will have to figure out how to do this.
    Then, I will have to learn to use the google colab interface to run the code.
    There are ways to send text with selenium, but I have to research how to send an entire code, or many lines of text
    """
    driver.get('https://colab.research.google.com/drive/1cUiAcrkhNmefJk2Hz0uI-9I3Zm6zQRJD?usp=sharing')
    cell1_xpath = '//div[contains(@aria-label, "Cell 0: Code cell: ")]'
    cell2_xpath = '//div[contains(@aria-label, "Cell 1: Code cell: ")]'
    cell2_output_xpath = '//div[contains(@class, "stream output-id-1 output_text")]'
    WebDriverWait(driver, 400).until(
        EC.presence_of_element_located((By.XPATH, cell1_xpath))
    )

    cell1 = driver.find_element(By.XPATH, cell1_xpath)
    action.click(cell1)
    action.key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL)
    action.send_keys(Keys.BACKSPACE)
    action.send_keys(Keys.HOME)
    action.send_keys('!pip install -i https://test.pypi.org/pypi/ --extra-index-url https://pypi.org/simple CRISPRcolab')
    action.send_keys(Keys.ENTER)
    action.send_keys('import CRISPRcolab as glib')
    action.perform()

    cell2 = driver.find_element(By.XPATH, cell2_xpath)
    action.click(cell2)
    action.send_keys(Keys.HOME)
    action.key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL)
    action.send_keys(Keys.BACKSPACE)
    action.send_keys('esse software vai ficar muito bom e vai ser muito útil')
    action.send_keys(Keys.END)
    action.send_keys(Keys.ENTER)
    action.send_keys('print("oi")')
    action.key_down(Keys.CONTROL).send_keys(Keys.ENTER).key_up(Keys.CONTROL)
    action.perform()

    time.sleep(10)
    cell2_output = driver.find_element(By.XPATH, cell2_output_xpath)
    action.click(cell2_output)
    action.perform()
    print(cell2_output.text)
    print(glib.main(cell2_output.text))
    time.sleep(100)

    #driver.quit()
    

app = App()
app.mainloop()

""" Coisas a fazer:
* Preciso adicionar a funcionalidade de pegar um gene ou genoma por meio de um link do NCBI.
* Preciso integrar as coisas que eu consegui fazer com o selenium e retirar os resultados do colab.
Se eu fizer tudo isso at'e amanha, vai ser mais facil de convencer a professora.
* Agora, para integrar a parte do selenium vai demorar um pouco, eu preciso trazer os códigos para cá,
acho que vou ter que fazer uma funç~ao só para isso mas vai dar bom. Depois eu preciso selecionar o código
que vai ser enviado ao colab, pode ser um de teste mesmo, mas eu queria pelo menos executar a mesma função que
a library local. Estou pensando em como fazer isso. Mas acho que eu consigo usando aquela função de import do
servidor de teste do pypi. Aí eu importo as libraries locais e rodo lá. Boa, já estou pensando em como fazer.
Eu preciso ver como pegar output das funções que eu rodar e aparecerem no colab lá.
Mas agora então eu vou migrar o código do selenium e vou estudar como funcionam as principais funçoes que eu estou
usando. Depois eu vou tentar rodar o código do colab e ver se eu consigo pegar o output. Se eu conseguir fazer isso
"""

