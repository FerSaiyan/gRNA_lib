from setuptools import setup, find_packages

with open('app/Readme.md', 'r') as file:
    long_description = file.read()
setup(
    name='CRISPRcolab',
    version='0.1.1',
    description='A package for CRISPR gRNA design and experiment analysis that runs in Google Colaboratory',
    package_dir={'': 'app'},
    packages=find_packages(where='app'),
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Akio Frazatto',
    author_email="fernandosaiyan10@gmail.com",
    url='https://github.com/FerSaiyan/CRISPRcolab',
    license='MIT',
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    include_package_data=True,
    install_requires=[
        'customtkinter',
    ],
    python_requires='>=3.6'
)
