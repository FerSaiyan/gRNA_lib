from Bio.Seq import Seq
from Bio import SeqIO, Entrez
import time
import csv
import numpy as np
import subprocess
import sys
import math
import pickle
from BioUtils import *
import os
# import gRNAScores.Rule_Set_2_scoring_v1.analysis.model_comparison as RS2; # Import Doench et al. (2016) old on-target scoring module
from cfd_score_calculator import * # Import Doench et al. (2016) off-target scoring module
#import gRNAScores.azimuth.model_comparison as azimuth # Import Doench et al. (2016) new on-target scoring module
import warnings
warnings.filterwarnings(action='ignore',category=UserWarning) # sklearn complains about loading pickled files from a different version, but they're okay

#gene_sequence = Seq("tataaatcgtccaatggtacctttaacaggtggtccatccGGGGaaaaaaaatttatatatggttattgtcggctaaggcctacctggactccggta")

#inside find_gRNA function
def find_gRNA(gene_sequence, sought_PAM, gRNA_size = 20):
    #PAM_idx_list = []
    PAM_var_list = [sought_PAM]
    print("The first PAM_var_list is:", PAM_var_list)
    #PAM_var_list.append([main_PAM][(len(main_PAM)/2)].upper())
    #print(PAM)
    #print(PAM.upper())
    #print(PAM_var_list)
    #print(PAM_var_list)
    #print(PAM_var_list)
    gRNA_list = []
    gene_sequence_str = str(gene_sequence)
    PAM_list = []
    PAM_ambiguous = False

    j = 0
    while j < len(PAM_var_list):
        aux_PAM = PAM_var_list[j]
        if 'N' in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('N')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'A' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'T' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'C' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'G' + aux_PAM[idx+1:])
        elif "R" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('R')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'A' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'G' + aux_PAM[idx+1:])
        elif "Y" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('Y')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'C' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'T' + aux_PAM[idx+1:])
        elif "V" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('V')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'A' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'C' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'G' + aux_PAM[idx+1:])
        elif "H" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('H')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'A' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'C' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'T' + aux_PAM[idx+1:])
        elif "D" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('D')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'A' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'G' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'T' + aux_PAM[idx+1:])
        elif "B" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('B')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'C' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'G' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'T' + aux_PAM[idx+1:])
        elif "M" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('M')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'A' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'C' + aux_PAM[idx+1:])
        elif "K" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('K')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'G' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'T' + aux_PAM[idx+1:])
        elif "S" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('S')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'C' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'G' + aux_PAM[idx+1:])
        elif "W" in aux_PAM:
            PAM_ambiguous = True
            idx = aux_PAM.find('W')
            PAM_var_list.pop(j)
            PAM_var_list.append(aux_PAM[:idx] + 'A' + aux_PAM[idx+1:])
            PAM_var_list.append(aux_PAM[:idx] + 'T' + aux_PAM[idx+1:])
        else:
            j += 1
    print(f"The {j} PAM_var_list is:", PAM_var_list)
    #print("Searching for PAMs:", PAM)
    for i in range(len(gene_sequence_str)): #Further speed improvements can be made here by storing the PAMs as is and only changing things in the comparison

        comparison_element = gene_sequence_str[i:i+len(sought_PAM)]
        for pam in PAM_var_list:
            if comparison_element == pam:
                PAM_list.append([i, pam])
    
    for k,l in PAM_list:
        if k < gRNA_size:
            continue
        gRNA_list.append([gene_sequence_str[k-gRNA_size:k], k, l])
    #print("The gRNA list is:", gRNA_list)
    return gRNA_list


def complimentary_sequence(gene_sequence):
    return gene_sequence.complement() #reverse complement?????

def offTargetScore(gRNA, method, enzyme, pamSeq, pamType, maxNumMisMatches=4, gListFilePath="", binExecPath="offTargetScoringBin"):
    platform = "Linux" # default to linux platform
    if sys.platform == "darwin": # if running on mac yosemite,
        platform = "OSX" # set new osx to access alternate binary file

    if gListFilePath == "": # if no argument was passed to gListFilePath
        if enzyme == "Cas9": # if enzyme is Cas9
            gListFilePath = "gListCas9.txt" # use this list
        elif enzyme == "Cas12": # if enzyme is Cas12
            gListFilePath = "gRNAScores/OffTarget_Scoring/gListCpf1.txt" # use cas12 list


    args = (f"{os.getcwd()}"+"/offTargetScoringBinLinux", gRNA, gListFilePath, method, pamSeq, pamType, str(maxNumMisMatches), "no") # stores command to be passed to console. "no" specifies output format as just scores.
    popen = subprocess.Popen(args, stdout=subprocess.PIPE) # passes command to console
    popen.wait(); # waits?
    output = popen.stdout.read() # get console output
    scores = [float(x) for x in output.decode("utf-8").replace('\n','').split(',')] # parse outputs as floats
    scores[2] = int(scores[2]) # parse third output as integer
    scores[3] = scores[3] == 1 # and fourth as Boolean
    return scores

def gRNA_ranking(gRNA_list, genome_sequence, Sp_cas9=True): # I will have to implement a bowtie search here
    ranking = {}
    off_target = {}
    GC_content = {}
    secondary_structure = {}
    poly_T = {}
    print(type(gRNA_list))
    print(np.array(gRNA_list).shape)

    if Sp_cas9 == True:
        print("We are using the CFD score")
        for n_gRNA in range(len(gRNA_list)):
            gRNA = gRNA_list[n_gRNA][0]
            GC_content[gRNA] = (gRNA.count('G') + gRNA.count('C'))/len(gRNA)
            poly_T[gRNA] = True
            if gRNA.find("TTTT") == -1: #if the gRNA has 4 consecutive Ts, it will reduce the score
                poly_T[gRNA] = False
            secondary_structure[gRNA] = False
            if gRNA.count('TTT') > 1 and gRNA.count('AAA') > 1:
                secondary_structure[gRNA] = True
            print("The gRNA being ranked is:", gRNA)
            result_of_rank = offTargetScore(gRNA, "cfd", "Cas9", "NGG", "NGG")
            #print("Figuring stuff out", result_of_rank)
            ranking[gRNA] = result_of_rank[0]
            off_target[gRNA] = result_of_rank[2]

        return [[gRNA, str(off_target[gRNA]), str(round(100*GC_content[gRNA], 2)), 
         str(secondary_structure[gRNA]), str(poly_T[gRNA]) , str(rank)
         ] 
         for gRNA, rank in sorted(ranking.items(), key=lambda x:x[1], reverse=True)
         ]
    
    else:
        print("We are using the exotic score")
        #print("The genome sequence is:", genome_sequence)
        for n_gRNA in range(len(gRNA_list)):
            gRNA = gRNA_list[n_gRNA][0] #retrieves a gRNA sequence from the list

            #print("The gRNA sequence is:", gRNA)

            #if gRNA[len(gRNA)-1] != 'G': #if the gRNA doesn't end with a G, it will add a G to the 5' end
            #    gRNA_list[n_gRNA][0] = 'G' + gRNA_list[n_gRNA][0] #adds a G to the end of the gRNA sequence
            #    #ranking[gRNA_list[n_gRNA][0]] = ranking.pop(gRNA) #adds the new fixed gRNA sequence to the ranking dictionary
            #    gRNA = gRNA_list[n_gRNA][0] #retrieves the new gRNA sequence
            #print(type(genome_sequence))
            print(gRNA)
            off_target[gRNA] = genome_sequence.count(gRNA) #counts the number of times the gRNA appears in the genome
            print("off_target[gRNA] is:", off_target[gRNA], gRNA)
            ranking[gRNA] = 0 #initializes the score for this gRNA
            ranking[gRNA] -= 20*(off_target[gRNA]-1) #reduces the score by 10 for each time the gRNA appears more than once in the genome

            poly_T[gRNA] = False
            if gRNA.find("TTTT") == -1: #if the gRNA has 4 consecutive Ts, it will reduce the score
                ranking[gRNA] = -10 #reduces the score by 10
                poly_T[gRNA] = True
                #continue

            GC_content[gRNA] = (gRNA.count('G') + gRNA.count('C'))/len(gRNA)
            if GC_content[gRNA] < 0.3 or GC_content[gRNA] >= 0.8:
                ranking[gRNA] += -30
            else:
                ranking[gRNA] += 30

            if gRNA[-4] == 'A' or gRNA[-4] == 'T' and Sp_cas9 == True:
                ranking[gRNA] += 20

            secondary_structure[gRNA] = False
            if gRNA.count('TTT') > 1 and gRNA.count('AAA') > 1:
                ranking[gRNA] += -10
                secondary_structure[gRNA] = True

        # For every gRNA, I also want to print some stats, so I will probably use pandas here
        return [[gRNA, str(off_target[gRNA]), str(round(100*GC_content[gRNA], 2)), 
                 str(secondary_structure[gRNA]), str(poly_T[gRNA]) , str(rank)
                 ] 
                 for gRNA, rank in sorted(ranking.items(), key=lambda x:x[1], reverse=True)
                 ]

    str1_print = "A 'G' may have been added to the end of some gRNA sequences to improve the efficiency"
    
def sequence_download(email, ids, database, rettype="fasta"):
    Entrez.email = email

    ids = ",".join(ids)
    handle = Entrez.efetch(db=database, id=ids, rettype=rettype)
    records = list(SeqIO.parse(handle, rettype))

    return records

def sequence_load(file_path, rettype="fasta"):
    records = list(SeqIO.parse(file_path, rettype))
    return records

def save_to_file(file_path, file, rettype="fasta"):
    SeqIO.write(file, file_path, rettype)

def save_to_csv(file_path, object):
    with open(file_path+'/'+str(int(time.time()/1000))+".csv", "w") as file:
        write = csv.writer(file)
        write.writerow(["gRNA", "number of off-targets", "GC_content %", "secondary_structure", "poly_T", "rank points"])
        write.writerows(object)
 
def main(gene_sequence_plus, PAM=["NGG"], show_sequence_minus=False):
    gRNA_list_plus = []
    gRNA_list_minus = []
    #main_PAM = PAM[0]
    gene_sequence_plus = gene_sequence_plus.upper() #input("Enter the gene sequence from 5' to 3': ").upper()
    gene_sequence_minus = complimentary_sequence(gene_sequence_plus)
    
    PAM_seqs = [pam.upper() for pam in PAM[0:len(PAM):2]]
    PAM_probs = [float(pam) for pam in PAM[1:len(PAM):2]]
    #print(PAM_seqs)
    #print(PAM_seqs)
    #print(PAM_seqs)
    counter = 0
    for sought_PAM in PAM_seqs:
        counter += 1
        print("calling find_gRNA")
        globals()[f'aux_{counter}_plus'] = find_gRNA(gene_sequence_plus, sought_PAM)
        globals()[f'aux_{counter}_minus'] = find_gRNA(gene_sequence_minus, sought_PAM)
        
    if counter == 1:
        return globals()[f'aux_{counter}_plus'], globals()[f'aux_{counter}_minus']
    elif counter == 2:
        return globals()[f'aux_{counter-1}_plus'], globals()[f'aux_{counter-1}_minus'], globals()[f'aux_{counter}_plus'], globals()[f'aux_{counter}_minus']
    elif counter == 3:
        return globals()[f'aux_{counter-2}_plus'],globals()[f'aux_{counter-2}_minus'],globals()[f'aux_{counter-1}_plus'],globals()[f'aux_{counter-1}_minus'],globals()[f'aux_{counter}_plus'],globals()[f'aux_{counter}_minus']
    else:
        raise Exception("There was a problem with the number of PAMs provided to main()")

if __name__ == "__main__":
    main()